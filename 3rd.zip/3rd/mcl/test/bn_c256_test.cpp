#include <mcl/bn256.hpp>
using namespace mcl::bn256;
#define MCLBN_DEFINE_STRUCT
#define MCLBN_FP_UNIT_SIZE 4
#include "bn_c_test.hpp"


if (typeof __dirname === 'string') {
  var Module = {}
  Module.wasmBinaryFile = __dirname + '/mcl_c.wasm'
}


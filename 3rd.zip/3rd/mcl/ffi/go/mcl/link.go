package mcl

/*
#cgo CFLAGS:-I ../../../include
#cgo LDFLAGS:-lmcl -lstdc++ -L../../../lib
*/
import "C"
